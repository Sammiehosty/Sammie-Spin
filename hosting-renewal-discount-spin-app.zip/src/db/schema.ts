import { pgTable, serial, varchar, integer, boolean, timestamp } from 'drizzle-orm/pg-core';

export const participants = pgTable('participants', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  whatsappNumber: varchar('whatsapp_number', { length: 20 }).notNull(),
  discountWon: integer('discount_won').notNull().default(0),
  balanceToPay: integer('balance_to_pay').notNull().default(10000),
  hasClaimed: boolean('has_claimed').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
