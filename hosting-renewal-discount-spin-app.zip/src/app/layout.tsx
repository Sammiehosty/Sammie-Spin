import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sammie Hosty - Spin & Win Discount",
  description:
    "Sammie Hosty customer appreciation spin & win event. Spin the wheel to win renewal discounts!",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-br from-[#0f0c29] via-[#302b63] to-[#24243e] text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
