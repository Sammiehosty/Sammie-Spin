'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function HomePage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim() || !whatsapp.trim()) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), whatsappNumber: whatsapp.trim() }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Something went wrong.');
        setLoading(false);
        return;
      }

      // Store result in sessionStorage for the spin page
      sessionStorage.setItem(
        'spinData',
        JSON.stringify({
          id: data.id,
          name: data.name,
          discount: data.discount,
          balanceToPay: data.balanceToPay,
          discountAmount: data.discountAmount,
        })
      );

      router.push('/spin');
    } catch {
      setError('Network error. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-8">
      {/* Logo & Header */}
      <div className="text-center mb-8 animate-fade-in">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-4 shadow-lg shadow-purple-500/30">
          <span className="text-3xl">🎰</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold bg-gradient-to-r from-purple-400 via-pink-400 to-yellow-400 bg-clip-text text-transparent">
          Sammie Hosty
        </h1>
        <p className="text-lg md:text-xl text-purple-200 mt-2">
          Customer Appreciation — Spin &amp; Win!
        </p>
      </div>

      {/* Description Card */}
      <div className="w-full max-w-md mb-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/10">
          <p className="text-center text-sm md:text-base text-purple-100 leading-relaxed">
            🎉 Is your hosting account about to expire or already suspended? 
            Spin the wheel to win a <span className="font-bold text-yellow-300">10% – 35% discount</span> on 
            your ₦10,000 monthly renewal fee!
          </p>
        </div>
      </div>

      {/* Registration Form */}
      <div className="w-full max-w-md animate-fade-in" style={{ animationDelay: '0.4s' }}>
        <form
          onSubmit={handleSubmit}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-6 md:p-8 border border-white/10 shadow-2xl"
        >
          <h2 className="text-xl font-bold text-center mb-6 text-white">
            Enter Your Details to Spin
          </h2>

          <div className="mb-4">
            <label
              htmlFor="name"
              className="block text-sm font-medium text-purple-200 mb-1.5"
            >
              Full Name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
              required
            />
          </div>

          <div className="mb-6">
            <label
              htmlFor="whatsapp"
              className="block text-sm font-medium text-purple-200 mb-1.5"
            >
              WhatsApp Number
            </label>
            <input
              id="whatsapp"
              type="tel"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="e.g. 08012345678"
              className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
              required
            />
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-sm text-center">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-lg shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {loading ? (
              <span className="inline-flex items-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Processing...
              </span>
            ) : (
              '🎲 Submit & Spin!'
            )}
          </button>

          <p className="text-xs text-center text-white/40 mt-4">
            Each WhatsApp number can only spin once. Discount is valid for hosting renewal only.
          </p>
        </form>
      </div>

      {/* Footer */}
      <p className="text-xs text-white/30 mt-8 text-center">
        © {new Date().getFullYear()} Sammie Hosty. All rights reserved.
      </p>
    </div>
  );
}
