'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';

interface SpinData {
  id: number;
  name: string;
  discount: number;
  balanceToPay: number;
  discountAmount: number;
}

const SEGMENTS = [
  { label: '10%', value: 10, color: '#10b981' },
  { label: 'NO WIN', value: 0, color: '#6b7280' },
  { label: '20%', value: 20, color: '#8b5cf6' },
  { label: 'TRY AGAIN', value: -1, color: '#374151' },
  { label: '30%', value: 30, color: '#ec4899' },
  { label: '15%', value: 15, color: '#3b82f6' },
  { label: '35%', value: 35, color: '#f59e0b' },
  { label: '25%', value: 25, color: '#ef4444' },
];

export default function SpinPage() {
  const router = useRouter();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [spinData, setSpinData] = useState<SpinData | null>(null);
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [confetti, setConfetti] = useState<{ id: number; left: string; color: string; delay: string; duration: string }[]>([]);

  // Load spin data from sessionStorage
  useEffect(() => {
    const data = sessionStorage.getItem('spinData');
    if (!data) {
      router.push('/');
      return;
    }
    setSpinData(JSON.parse(data));
  }, [router]);

  // Draw the wheel on canvas
  const drawWheel = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 400;
    canvas.width = size;
    canvas.height = size;
    const center = size / 2;
    const radius = size / 2 - 12;
    const arc = (2 * Math.PI) / SEGMENTS.length;

    // Clear
    ctx.clearRect(0, 0, size, size);

    // Draw outer ring
    ctx.beginPath();
    ctx.arc(center, center, radius + 8, 0, 2 * Math.PI);
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Draw segments
    SEGMENTS.forEach((seg, i) => {
      const startAngle = i * arc - Math.PI / 2;
      const endAngle = startAngle + arc;

      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw text
      ctx.save();
      ctx.translate(center, center);
      ctx.rotate(startAngle + arc / 2);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.shadowBlur = 4;
      ctx.fillText(seg.label, radius * 0.65, 0);
      ctx.restore();
    });

    // Draw center circle
    ctx.beginPath();
    ctx.arc(center, center, 28, 0, 2 * Math.PI);
    ctx.fillStyle = '#1e1b4b';
    ctx.fill();
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Center dot
    ctx.beginPath();
    ctx.arc(center, center, 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#facc15';
    ctx.fill();
  }, []);

  useEffect(() => {
    drawWheel();
  }, [drawWheel]);

  const spin = () => {
    if (spinning || !spinData) return;
    setSpinning(true);
    setShowResult(false);

    // Find target segment
    let targetIndex: number;
    if (spinData.discount > 0) {
      targetIndex = SEGMENTS.findIndex((s) => s.value === spinData.discount);
      if (targetIndex === -1) targetIndex = 0;
    } else {
      // No discount — pick a "NO WIN" or "TRY AGAIN" segment
      const noWinIndices = SEGMENTS.map((s, i) => ({ v: s.value, i }))
        .filter((s) => s.v <= 0)
        .map((s) => s.i);
      targetIndex = noWinIndices[Math.floor(Math.random() * noWinIndices.length)];
    }

    // Calculate target rotation
    const segDeg = 360 / SEGMENTS.length; // 45
    const offset = Math.random() * 20 + 12; // 12-32 degrees within segment
    const targetRotation = 360 * 8 + targetIndex * segDeg + offset;

    setRotation(targetRotation);

    // Show result after animation
    setTimeout(() => {
      setSpinning(false);
      setShowResult(true);

      // Confetti for winners
      if (spinData.discount > 0) {
        const colors = ['#f59e0b', '#ec4899', '#8b5cf6', '#10b981', '#3b82f6', '#ef4444'];
        const pieces = Array.from({ length: 30 }, (_, i) => ({
          id: i,
          left: Math.random() * 100 + '%',
          color: colors[Math.floor(Math.random() * colors.length)],
          delay: Math.random() * 1 + 's',
          duration: Math.random() * 2 + 2 + 's',
        }));
        setConfetti(pieces);
        setTimeout(() => setConfetti([]), 5000);
      }
    }, 5500);
  };

  if (!spinData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-purple-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  const whatsappLink = `https://wa.me/2349132733999?text=${encodeURIComponent(
    `I won a discount of ${spinData.discount}% (₦${spinData.discountAmount.toLocaleString()} off). My renewal balance is ₦${spinData.balanceToPay.toLocaleString()}.`
  )}`;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-8">
      {/* Confetti */}
      {confetti.map((c) => (
        <div
          key={c.id}
          className="confetti-piece rounded-sm"
          style={{
            left: c.left,
            backgroundColor: c.color,
            animationDelay: c.delay,
            animationDuration: c.duration,
            top: '-10px',
          }}
        />
      ))}

      {/* Header */}
      <div className="text-center mb-4 animate-fade-in">
        <h1 className="text-2xl md:text-3xl font-bold text-white">
          🎰 Spin the Wheel!
        </h1>
        <p className="text-purple-200 mt-1">
          Hello, <span className="font-semibold text-yellow-300">{spinData.name}</span>!
        </p>
      </div>

      {/* Wheel Container */}
      <div className="relative mb-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10">
          <div className="w-0 h-0 border-l-[14px] border-r-[14px] border-t-[28px] border-l-transparent border-r-transparent border-t-yellow-400 drop-shadow-lg" />
        </div>

        {/* Wheel */}
        <canvas
          ref={canvasRef}
          className="max-w-[300px] md:max-w-[380px] w-full rounded-full"
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: spinning
              ? 'transform 5s cubic-bezier(0.17, 0.67, 0.12, 0.99)'
              : 'none',
          }}
        />
      </div>

      {/* Spin Button */}
      {!showResult && (
        <button
          onClick={spin}
          disabled={spinning}
          className={`px-10 py-4 rounded-2xl font-bold text-lg text-white shadow-2xl transition-all duration-200 cursor-pointer ${
            spinning
              ? 'bg-gray-600 cursor-not-allowed opacity-50'
              : 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 shadow-orange-500/30 hover:shadow-orange-500/50 animate-pulse-glow'
          }`}
        >
          {spinning ? '🎰 Spinning...' : '🎰 SPIN NOW!'}
        </button>
      )}

      {/* Result */}
      {showResult && (
        <div className="w-full max-w-md animate-fade-in">
          {spinData.discount > 0 ? (
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 md:p-8 border border-white/10 shadow-2xl text-center">
              <div className="animate-bounce-in">
                <span className="text-6xl block mb-3">🎉</span>
                <h2 className="text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-yellow-300 to-pink-400 bg-clip-text text-transparent mb-2">
                  CONGRATULATIONS!
                </h2>
                <p className="text-lg text-purple-100 mb-4">
                  You won a <span className="font-bold text-yellow-300">{spinData.discount}% discount!</span>
                </p>
              </div>

              <div className="bg-black/20 rounded-xl p-4 mb-5 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-purple-200">Original Renewal Fee:</span>
                  <span className="text-white line-through">₦10,000</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-200">Discount ({spinData.discount}%):</span>
                  <span className="text-green-400 font-semibold">-₦{spinData.discountAmount.toLocaleString()}</span>
                </div>
                <div className="border-t border-white/10 pt-2 flex justify-between font-bold text-lg">
                  <span className="text-white">Balance to Pay:</span>
                  <span className="text-yellow-300">₦{spinData.balanceToPay.toLocaleString()}</span>
                </div>
              </div>

              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white font-bold text-lg shadow-lg shadow-green-500/30 hover:shadow-green-500/50 transition-all duration-200"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                Claim Your Discount
              </a>
            </div>
          ) : (
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 md:p-8 border border-white/10 shadow-2xl text-center">
              <span className="text-6xl block mb-3">😔</span>
              <h2 className="text-2xl font-bold text-white mb-2">
                Better Luck Next Time!
              </h2>
              <p className="text-purple-200 mb-4">
                Unfortunately, you didn&apos;t win a discount this time.
              </p>
              <div className="bg-black/20 rounded-xl p-4">
                <div className="flex justify-between font-bold text-lg">
                  <span className="text-white">Renewal Fee:</span>
                  <span className="text-yellow-300">₦10,000</span>
                </div>
              </div>
              <p className="text-sm text-white/40 mt-4">
                Contact Sammie Hosty to renew your hosting account.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
