import { db } from '@/db';
import { participants } from '@/db/schema';
import { eq, gt, sql } from 'drizzle-orm';
import { NextRequest, NextResponse } from 'next/server';

const TOTAL_CUSTOMERS = 60;
const MAX_WINNERS = Math.floor(TOTAL_CUSTOMERS * 0.4); // 24
const BASE_FEE = 10000;
const SPECIAL_NUMBER = '08012345678';

const DISCOUNT_OPTIONS = [10, 15, 20, 25, 30, 35];
const DISCOUNT_WEIGHTS = [5, 4, 3, 2, 1, 1];

function getWeightedDiscount(): number {
  const totalWeight = DISCOUNT_WEIGHTS.reduce((a, b) => a + b, 0);
  let random = Math.random() * totalWeight;
  for (let i = 0; i < DISCOUNT_OPTIONS.length; i++) {
    random -= DISCOUNT_WEIGHTS[i];
    if (random <= 0) return DISCOUNT_OPTIONS[i];
  }
  return DISCOUNT_OPTIONS[0];
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const whatsappNumber = typeof body.whatsappNumber === 'string' ? body.whatsappNumber.trim() : '';

    if (!name || !whatsappNumber) {
      return NextResponse.json(
        { error: 'Name and WhatsApp number are required.' },
        { status: 400 }
      );
    }

    // Check duplicate
    const existing = await db
      .select()
      .from(participants)
      .where(eq(participants.whatsappNumber, whatsappNumber));

    if (existing.length > 0) {
      return NextResponse.json(
        {
          error:
            'This WhatsApp number has already been used. Each number can only spin once!',
        },
        { status: 400 }
      );
    }

    // Count current stats
    const [{ total: totalParticipants }] = await db
      .select({ total: sql<number>`cast(count(*) as int)` })
      .from(participants);

    const [{ total: currentWinners }] = await db
      .select({ total: sql<number>`cast(count(*) as int)` })
      .from(participants)
      .where(gt(participants.discountWon, 0));

    // Determine discount
    let discount = 0;

    if (whatsappNumber === SPECIAL_NUMBER) {
      discount = 10;
    } else if (currentWinners >= MAX_WINNERS) {
      discount = 0;
    } else {
      const remainingSlots = MAX_WINNERS - currentWinners;
      const remainingPotential = Math.max(
        TOTAL_CUSTOMERS - totalParticipants,
        remainingSlots
      );
      const probability = remainingSlots / remainingPotential;

      if (Math.random() < probability) {
        discount = getWeightedDiscount();
      }
    }

    const discountAmount = Math.floor((BASE_FEE * discount) / 100);
    const balanceToPay = BASE_FEE - discountAmount;

    const result = await db
      .insert(participants)
      .values({
        name,
        whatsappNumber,
        discountWon: discount,
        balanceToPay,
      })
      .returning();

    return NextResponse.json({
      id: result[0].id,
      name: result[0].name,
      discount: result[0].discountWon,
      balanceToPay: result[0].balanceToPay,
      discountAmount,
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'An error occurred. Please try again.' },
      { status: 500 }
    );
  }
}
