import { NextRequest, NextResponse } from 'next/server';
import { validateSession } from '@/lib/auth';
import { db } from '@/db';
import { participants } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = request.cookies.get('admin_session')?.value;
  if (!validateSession(token)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { id } = await params;
  const participantId = parseInt(id, 10);

  if (isNaN(participantId)) {
    return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });
  }

  await db
    .update(participants)
    .set({ hasClaimed: true })
    .where(eq(participants.id, participantId));

  return NextResponse.json({ success: true });
}
