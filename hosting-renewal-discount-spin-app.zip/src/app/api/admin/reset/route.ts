import { NextRequest, NextResponse } from 'next/server';
import { validateSession } from '@/lib/auth';
import { db } from '@/db';
import { participants } from '@/db/schema';
import { sql } from 'drizzle-orm';

export async function DELETE(request: NextRequest) {
  const token = request.cookies.get('admin_session')?.value;
  if (!validateSession(token)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  await db.delete(participants);

  // Reset the serial sequence
  await sql`SELECT setval(pg_get_serial_sequence('participants', 'id'), 1, false)`;

  return NextResponse.json({ success: true, message: 'All participants removed.' });
}
