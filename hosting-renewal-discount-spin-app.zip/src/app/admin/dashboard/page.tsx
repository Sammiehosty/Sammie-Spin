'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';

interface Participant {
  id: number;
  name: string;
  whatsappNumber: string;
  discountWon: number;
  balanceToPay: number;
  hasClaimed: boolean;
  createdAt: string;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);
  const [claimingId, setClaimingId] = useState<number | null>(null);

  const fetchParticipants = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/participants');
      if (res.status === 401) {
        router.push('/admin');
        return;
      }
      const data = await res.json();
      setParticipants(data.participants || []);
    } catch {
      setError('Failed to load participants.');
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    const verify = async () => {
      try {
        const res = await fetch('/api/admin/verify');
        if (!res.ok) {
          router.push('/admin');
          return;
        }
        fetchParticipants();
      } catch {
        router.push('/admin');
      }
    };
    verify();
  }, [fetchParticipants, router]);

  const handleClaim = async (id: number) => {
    setClaimingId(id);
    try {
      const res = await fetch(`/api/admin/claim/${id}`, { method: 'PATCH' });
      if (res.ok) {
        setParticipants((prev) =>
          prev.map((p) => (p.id === id ? { ...p, hasClaimed: true } : p))
        );
      }
    } catch {
      // silently fail
    }
    setClaimingId(null);
  };

  const handleReset = async () => {
    try {
      const res = await fetch('/api/admin/reset', { method: 'DELETE' });
      if (res.ok) {
        setParticipants([]);
        setConfirmReset(false);
      }
    } catch {
      // silently fail
    }
  };

  const handleLogout = async () => {
    document.cookie = 'admin_session=; path=/; max-age=0';
    router.push('/admin');
  };

  // Stats
  const totalParticipants = participants.length;
  const totalWinners = participants.filter((p) => p.discountWon > 0).length;
  const totalClaimed = participants.filter((p) => p.hasClaimed && p.discountWon > 0).length;
  const remainingSlots = 24 - totalWinners;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-purple-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen px-4 py-6 md:px-8 md:py-10">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white">
              📊 Sammie Hosty Admin
            </h1>
            <p className="text-sm text-purple-200 mt-1">Spin & Win Dashboard</p>
          </div>
          <button
            onClick={handleLogout}
            className="px-5 py-2 rounded-xl bg-red-600/20 border border-red-500/30 text-red-300 hover:bg-red-600/30 transition text-sm font-medium cursor-pointer"
          >
            Logout
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-8">
          <StatCard label="Total Participants" value={totalParticipants} color="purple" />
          <StatCard label="Discount Winners" value={`${totalWinners} / 24`} color="green" />
          <StatCard label="Claimed" value={totalClaimed} color="blue" />
          <StatCard
            label="Remaining Slots"
            value={remainingSlots}
            color={remainingSlots > 0 ? 'yellow' : 'red'}
          />
        </div>

        {/* Actions */}
        <div className="mb-6">
          <button
            onClick={() => fetchParticipants()}
            className="px-5 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition text-sm font-medium mr-3 cursor-pointer"
          >
            🔄 Refresh
          </button>
          <button
            onClick={() => setConfirmReset(true)}
            className="px-5 py-2.5 rounded-xl bg-red-600/20 border border-red-500/30 text-red-300 hover:bg-red-600/30 transition text-sm font-medium cursor-pointer"
          >
            🗑️ Remove All Participants
          </button>
        </div>

        {/* Confirm Reset Modal */}
        {confirmReset && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 px-4">
            <div className="bg-[#1e1b4b] rounded-2xl p-6 max-w-sm w-full border border-white/10 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-2">⚠️ Confirm Reset</h3>
              <p className="text-sm text-purple-200 mb-5">
                This will remove ALL participant records so they can spin again. This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={handleReset}
                  className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-bold hover:bg-red-500 transition cursor-pointer"
                >
                  Yes, Remove All
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-medium hover:bg-white/20 transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-sm text-center">
            {error}
          </div>
        )}

        {/* Participants Table */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden">
          <div className="p-4 md:p-5 border-b border-white/10">
            <h2 className="text-lg font-bold text-white">Participants ({totalParticipants})</h2>
          </div>

          {participants.length === 0 ? (
            <div className="p-10 text-center text-purple-300">
              <span className="text-4xl block mb-3">📭</span>
              No participants yet. Share the spin link with your customers!
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left">
                    <th className="px-4 py-3 text-purple-200 font-medium">#</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">Name</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">WhatsApp</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">Discount</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">Balance</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">Status</th>
                    <th className="px-4 py-3 text-purple-200 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {participants.map((p, idx) => (
                    <tr
                      key={p.id}
                      className="border-b border-white/5 hover:bg-white/5 transition"
                    >
                      <td className="px-4 py-3 text-white/60">{idx + 1}</td>
                      <td className="px-4 py-3 text-white font-medium">{p.name}</td>
                      <td className="px-4 py-3 text-white/80 font-mono text-xs md:text-sm">
                        {p.whatsappNumber}
                      </td>
                      <td className="px-4 py-3">
                        {p.discountWon > 0 ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-500/20 text-green-300 border border-green-500/30">
                            {p.discountWon}%
                          </span>
                        ) : (
                          <span className="text-white/40">None</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-yellow-300 font-semibold">
                        ₦{p.balanceToPay.toLocaleString()}
                      </td>
                      <td className="px-4 py-3">
                        {p.discountWon > 0 ? (
                          p.hasClaimed ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                              ✅ Claimed
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-500/20 text-orange-300 border border-orange-500/30">
                              ⏳ Pending
                            </span>
                          )
                        ) : (
                          <span className="text-white/30">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {p.discountWon > 0 && !p.hasClaimed ? (
                          <button
                            onClick={() => handleClaim(p.id)}
                            disabled={claimingId === p.id}
                            className="px-3 py-1.5 rounded-lg bg-green-600/20 border border-green-500/30 text-green-300 hover:bg-green-600/30 transition text-xs font-medium cursor-pointer disabled:opacity-50"
                          >
                            {claimingId === p.id ? '...' : 'Mark Claimed'}
                          </button>
                        ) : (
                          <span className="text-white/20 text-xs">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-xs text-white/20 mt-8 text-center">
          © {new Date().getFullYear()} Sammie Hosty Admin Panel
        </p>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string | number;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    purple: 'from-purple-600/20 to-purple-800/10 border-purple-500/20 text-purple-300',
    green: 'from-green-600/20 to-green-800/10 border-green-500/20 text-green-300',
    blue: 'from-blue-600/20 to-blue-800/10 border-blue-500/20 text-blue-300',
    yellow: 'from-yellow-600/20 to-yellow-800/10 border-yellow-500/20 text-yellow-300',
    red: 'from-red-600/20 to-red-800/10 border-red-500/20 text-red-300',
  };

  const cls = colorMap[color] || colorMap.purple;

  return (
    <div
      className={`bg-gradient-to-br ${cls} border rounded-xl p-4 text-center`}
    >
      <p className="text-xs text-white/50 mb-1">{label}</p>
      <p className="text-2xl font-extrabold">{value}</p>
    </div>
  );
}
