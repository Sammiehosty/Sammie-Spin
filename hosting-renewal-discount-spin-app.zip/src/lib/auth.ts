import crypto from 'crypto';

// Obfuscated credentials — never stored as readable strings
const _k1 = [0x38,0x39,0x65,0x35,0x61,0x65,0x30,0x39];
const _k2 = [0x37,0x31,0x34,0x64,0x61,0x38,0x33,0x33];
const _k3 = [0x33,0x63,0x37,0x61,0x39,0x33,0x64,0x62];
const _k4 = [0x38,0x34,0x30,0x30,0x66,0x66,0x35,0x35];
const _k5 = [0x36,0x35,0x62,0x63,0x62,0x39,0x31,0x39];
const _k6 = [0x62,0x34,0x61,0x65,0x36,0x32,0x32,0x66];
const _k7 = [0x30,0x30,0x35,0x65,0x37,0x30,0x31,0x62];
const _k8 = [0x35,0x64,0x66,0x36,0x62,0x37,0x30,0x35];

const _ref = [_k1,_k2,_k3,_k4,_k5,_k6,_k7,_k8]
  .map(a => a.map(c => String.fromCharCode(c)).join(''))
  .join('');

const _uid = [0x64,0x69,0x73,0x63,0x6f,0x72,0x64]
  .map(c => String.fromCharCode(c)).join('');

export function verifyCredentials(username: string, password: string): boolean {
  if (username !== _uid) return false;
  const hash = crypto.createHash('sha256').update(password).digest('hex');
  return hash === _ref;
}

const sessions = new Map<string, number>();

export function createSession(): string {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now());
  return token;
}

export function validateSession(token: string | undefined): boolean {
  if (!token) return false;
  const ts = sessions.get(token);
  if (!ts) return false;
  if (Date.now() - ts > 24 * 60 * 60 * 1000) {
    sessions.delete(token);
    return false;
  }
  return true;
}

export function destroySession(token: string): void {
  sessions.delete(token);
}
